'use strict';

module.exports = function(ProScheduleChange) {

};
