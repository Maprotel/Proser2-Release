"use strict";

module.exports = function(Command) {};
