'use strict';


module.exports = function(RealCurrentBreaks) {

};
