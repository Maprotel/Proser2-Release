'use strict';


module.exports = function(RealCallEntry) {

};
