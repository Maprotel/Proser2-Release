# close openforti
ps aux | grep openforti