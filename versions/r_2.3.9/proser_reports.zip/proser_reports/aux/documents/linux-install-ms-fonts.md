
# Install Micosoft Fonts

sudo apt-get install ttf-mscorefonts-installer



Try to download debian pkg and install.

wget http://ftp.de.debian.org/debian/pool/contrib/m/msttcorefonts/ttf-mscorefonts-installer_3.6_all.deb

sudo dpkg -i ttf-mscorefonts-installer_3.6_all.deb