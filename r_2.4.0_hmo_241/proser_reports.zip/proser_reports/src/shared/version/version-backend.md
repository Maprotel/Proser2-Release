# Version Backend

## 2.3.7
- Se incluye carpeta shared con version control


## 2.3.6
- Desacople del frontend. En esta version se ajusto los valores del .env para el uso con la nueva estrategia desacoplada