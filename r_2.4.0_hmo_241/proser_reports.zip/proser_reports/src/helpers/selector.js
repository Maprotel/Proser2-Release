// let selectionByUser = {

//   selection_name;
//   seleccion_title;
//   selection_subtitle;

//   start_date;
//   end_date;

//   start_time;
//   end_time;

//   minutes_interval;
//   hours_interval;
//   days_interval;
//   month_interval;

//   agent;
//   agentBreak;
//   campaign;
//   client;
//   queue;
//   scale;
//   schedule;
//   service;
//   supervisor;
//   team;
//   project;

// }
