'use strict';


module.exports = function(InvCalendar) {

};
