'use strict';


module.exports = function(RealCurrentCalls) {

};
