import * as pool from '../../../../connectors/pool';
import moment from 'moment';

async function automaticsIndicators(userSelection) {

}

export {
  automaticsIndicators
};