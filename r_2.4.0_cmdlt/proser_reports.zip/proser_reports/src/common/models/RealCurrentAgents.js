'use strict';


module.exports = function(RealCurrentAgents) {

};
