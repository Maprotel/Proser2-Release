'use strict';

module.exports = function(Test) {

};
