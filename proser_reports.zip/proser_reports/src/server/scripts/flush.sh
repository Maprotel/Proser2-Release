#!/bin/bash
mysqladmin flush-hosts -u root -p
