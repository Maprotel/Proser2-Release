function addOne(number) {
  return number + 1;
}

module.exports = {
  addOne
}
